package Concesionario;
import java.util.Scanner;

public class Principal {

    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        Concesionario concesionario = new Concesionario();
        int opcion;

        do {
            mostrarMenu();
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1: nuevoVehiculo(concesionario);
                case 2: concesionario.listaVehiculos();
                case 3: concesionario.listarMenos100k();
                case 4: buscarVehiculo(concesionario);
                case 5: modificarKms(concesionario);
                case 6: System.out.println("Saliendo...");
                default: System.out.println("Opción incorrecta");
            }

        } while (opcion != 6);
    }

    private static void mostrarMenu() {
        System.out.println("""
            1. Nuevo Vehículo
            2. Listar Vehículos
            3. Listar Vehículos con menos de 100.000 km
            4. Buscar Vehículo
            5. Modificar km Vehículo
            6. Salir
        """);
    }

    private static void nuevoVehiculo(Concesionario c) {
        System.out.print("Marca: ");
        String marca = sc.nextLine();

        System.out.print("Modelo: ");
        String modelo = sc.nextLine();

        System.out.print("Color: ");
        String color = sc.nextLine();

        String matricula;
        do {
            System.out.print("Matrícula (NNNNLLL): ");
            matricula = sc.nextLine();
        } while (!matricula.matches("\\d{4}[A-Z]{3}"));

        System.out.print("Precio: ");
        double precio = sc.nextDouble();

        System.out.print("Kilómetros: ");
        int kms = sc.nextInt();
        sc.nextLine();

        System.out.print("Descripción: ");
        String desc = sc.nextLine();

        int res = c.insertarVehiculo(marca, modelo, color, matricula, precio, kms, desc);

        if (res == 0) System.out.println("Vehículo añadido correctamente");
        else if (res == -1) System.out.println("Concesionario lleno");
        else System.out.println("Matrícula duplicada");
    }

    private static void buscarVehiculo(Concesionario c) {
        System.out.print("Matrícula: ");
        String m = sc.nextLine();
        String res = c.buscaVehiculo(m);

        if (res == null)
            System.out.println("No existe vehículo con esa matrícula");
        else
            System.out.println(res);
    }

    private static void modificarKms(Concesionario c) {
        System.out.print("Matrícula: ");
        String m = sc.nextLine();

        System.out.print("Nuevos kilómetros: ");
        int kms = sc.nextInt();
        sc.nextLine();

        if (c.actualizaKms(m, kms))
            System.out.println("Kilómetros actualizados");
        else
            System.out.println("Vehículo no encontrado");
    }
}

