package Concesionario;

/**
 * Autor: Adrián
 * Descripción: Representa un vehículo de segunda mano del concesionario.
 */
public class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private String matricula;
    private double precio;
    private int kilometros;
    private String descripcion;

    public Vehiculo(String marca, String modelo, String color, String matricula,
                    double precio, int kilometros, String descripcion) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
        this.precio = precio;
        this.kilometros = kilometros;
        this.descripcion = descripcion;
    }

    public Vehiculo(int numBastidor, String marca, String modelo, String color, float precio) {
    }

    public String getMarca() { return marca; }
    public String getModelo() { return modelo; }
    public String getMatricula() { return matricula; }
    public double getPrecio() { return precio; }
    public int getKilometros() { return kilometros; }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    @Override
    public String toString() {
        return marca + " " + modelo + " | " + color +
                " | Matrícula: " + matricula +
                " | Precio: " + precio +
                " | Km: " + kilometros +
                " | " + descripcion;
    }
}
