package Concesionario;
import java.util.ArrayList;
import java.util.Comparator;

public class Concesionario {

    private ArrayList<Vehiculo> vehiculos;
    private static final int MAX_VEHICULOS = 50;

    public Concesionario() {
        vehiculos = new ArrayList<>();
    }


     // Inserta un vehículo en el concesionario.

    public int insertarVehiculo(String marca, String modelo, String color,
                                String matricula, double precio,
                                int kilometros, String descripcion) {

        if (vehiculos.size() >= MAX_VEHICULOS) {
            return -1;
        }

        for (Vehiculo v : vehiculos) {
            if (v.getMatricula().equalsIgnoreCase(matricula)) {
                return -2;
            }
        }

        vehiculos.add(new Vehiculo(marca, modelo, color, matricula, precio, kilometros, descripcion));
        return 0;
    }


     // Busca un vehículo por matrícula.

    public String buscaVehiculo(String matricula) {
        for (Vehiculo v : vehiculos) {
            if (v.getMatricula().equalsIgnoreCase(matricula)) {
                return "Marca: " + v.getMarca() +
                        " | Matrícula: " + v.getMatricula() +
                        " | Precio: " + v.getPrecio();
            }
        }
        return null;
    }


     // Lista todos los vehículos ordenados.

    public void listaVehiculos() {
        vehiculos.sort(
                Comparator.comparing(Vehiculo::getMarca)
                        .thenComparing(Vehiculo::getModelo)
                        .thenComparingInt(Vehiculo::getKilometros)
        );

        for (Vehiculo v : vehiculos) {
            System.out.println(v);
        }
    }


     // Actualiza los kilómetros de un vehículo.

    public boolean actualizaKms(String matricula, int kms) {
        for (Vehiculo v : vehiculos) {
            if (v.getMatricula().equalsIgnoreCase(matricula)) {
                v.setKilometros(kms);
                return true;
            }
        }
        return false;
    }


     // Lista vehículos con menos de 100.000 km.

    public void listarMenos100k() {
        ArrayList<Vehiculo> lista = new ArrayList<>();

        for (Vehiculo v : vehiculos) {
            if (v.getKilometros() < 100000) {
                lista.add(v);
            }
        }

        for (Vehiculo v : lista) {
            System.out.println(v);
        }
    }
}
