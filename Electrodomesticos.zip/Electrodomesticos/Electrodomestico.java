public class Electrodomestico {

    // Constantes por defecto
    protected static final double PRECIO_BASE_DEFECTO = 100;
    protected static final String COLOR_DEFECTO = "blanco";
    protected static final char CONSUMO_DEFECTO = 'F';
    protected static final double PESO_DEFECTO = 5;

    // Atributos
    protected double precioBase;
    protected String color;
    protected char consumoEnergetico;
    protected double peso;

    // Constructor por defecto
    public Electrodomestico() {
        this.precioBase = PRECIO_BASE_DEFECTO;
        this.peso = PESO_DEFECTO;
        this.consumoEnergetico = CONSUMO_DEFECTO;
        this.color = COLOR_DEFECTO;
    }

    // Constructor con precio y peso
    public Electrodomestico(double precioBase, double peso) {
        this.precioBase = precioBase;
        this.peso = peso;
        this.consumoEnergetico = CONSUMO_DEFECTO;
        this.color = COLOR_DEFECTO;
    }

    // Constructor con todos los atributos
    public Electrodomestico(double precioBase, String color, char consumoEnergetico, double peso) {
        this.precioBase = precioBase;
        this.peso = peso;
        comprobarConsumoEnergetico(consumoEnergetico);
        comprobarColor(color);
    }

    // Getters
    public double getPrecioBase() {
        return precioBase;
    }

    public String getColor() {
        return color;
    }

    public char getConsumoEnergetico() {
        return consumoEnergetico;
    }

    public double getPeso() {
        return peso;
    }

    // Comprueba consumo energético
    private void comprobarConsumoEnergetico(char letra) {
        if (letra >= 'A' && letra <= 'F') {
            this.consumoEnergetico = letra;
        } else {
            this.consumoEnergetico = CONSUMO_DEFECTO;
        }
    }

    // Comprueba color
    private void comprobarColor(String color) {
        String[] colores = {"blanco", "negro", "rojo", "azul", "gris"};
        boolean valido = false;

        for (String c : colores) {
            if (c.equalsIgnoreCase(color)) {
                this.color = c.toLowerCase();
                valido = true;
                break;
            }
        }

        if (!valido) {
            this.color = COLOR_DEFECTO;
        }
    }

    // Precio final
    public double precioFinal() {
        double precioFinal = precioBase;

        // Incremento por consumo energético
        switch (consumoEnergetico) {
            case 'A':
                precioFinal += 100;
                break;
            case 'B':
                precioFinal += 80;
                break;
            case 'C':
                precioFinal += 60;
                break;
            case 'D':
                precioFinal += 50;
                break;
            case 'E':
                precioFinal += 30;
                break;
            case 'F':
                precioFinal += 10;
                break;
        }

        // Incremento por peso
        if (peso >= 0 && peso <= 19) {
            precioFinal += 10;
        } else if (peso <= 49.9) {
            precioFinal += 50;
        } else if (peso <= 79) {
            precioFinal += 80;
        } else {
            precioFinal += 100;
        }

        return precioFinal;
    }
}


