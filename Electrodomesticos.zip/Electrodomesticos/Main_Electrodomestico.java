import java.util.ArrayList;

public class Main_Electrodomestico {

    public static void main(String[] args) {

        ArrayList<Electrodomestico> electrodomesticos = new ArrayList<>();

        // Creamos 3 lavadoras
        Lavadora l1 = new Lavadora();
        Lavadora l2 = new Lavadora(300, 45.5);
        Lavadora l3 = new Lavadora(300, "rojo", 'A', 30, 45, true, "Lana");

        electrodomesticos.add(l1);
        electrodomesticos.add(l2);
        electrodomesticos.add(l3);

        // Creamos 3 televisores
        Television t1 = new Television(500, "negro", 'B', 35, 50, true, "Netflix");
        Television t2 = new Television(550, 16);
        Television t3 = new Television(500, "negro", 'B', 35, 50, true, "Netflix");

        electrodomesticos.add(t1);
        electrodomesticos.add(t2);
        electrodomesticos.add(t3);

        // ---- 1 ----
        System.out.println("----1----");
        System.out.println("Recorremos el ArrayList invocando el método Alexa");
        System.out.println("-----------------------------------------------");

        for (Electrodomestico e : electrodomesticos) {
            if (e instanceof Lavadora) {
                ((Lavadora) e).dimeAlexa();
            } else if (e instanceof Television) {
                ((Television) e).dimeAlexa();
            }
        }

        // ---- 2 ----
        System.out.println("\n----2----");
        System.out.println("Recorremos el ArrayList invocando el método Precio final");
        System.out.println("-----------------------------------------------");

        double totalLavadoras = 0;
        double totalTelevisiones = 0;
        double totalElectrodomesticos = 0;

        for (Electrodomestico e : electrodomesticos) {
            double precio = e.precioFinal();

            if (e instanceof Lavadora) {
                System.out.println("La lavadora con precio " + e.getPrecioBase()
                        + " tiene un precio final de " + precio);
                totalLavadoras += precio;
            } else if (e instanceof Television) {
                System.out.println("La TV con precio " + e.getPrecioBase()
                        + " tiene un precio final de " + precio);
                totalTelevisiones += precio;
            }

            totalElectrodomesticos += precio;
        }

        // ---- 3 ----
        System.out.println("\n----3----");
        System.out.println("Mostramos el precio de cada clase:");
        System.out.println("-----------------------------------------------");

        System.out.println("Precio total Televisores: " + totalTelevisiones);
        System.out.println("Precio total Lavadoras: " + totalLavadoras);
        System.out.println("Precio total electrodomésticos: " + totalElectrodomesticos);
    }
}
