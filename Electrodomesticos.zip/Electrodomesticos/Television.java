public class Television extends Electrodomestico implements Alexa {

    // Atributos por defecto
    private static final int RESOLUCION_DEF = 32;
    private static final boolean SMARTTV_DEF = false;
    private static final String CANAL_DEF = "La 1 HD";

    // Atributos
    private int resolucion;
    private boolean smartTV;
    private String canal;

    // Constructor por defecto
    public Television(int i, String negro, char b, int i1, int i2, boolean b1, String netflix) {
        super();
        this.resolucion = RESOLUCION_DEF;
        this.smartTV = SMARTTV_DEF;
        this.canal = CANAL_DEF;
    }

    // Constructor con precio y peso
    public Television(double precio, double peso) {
        super(precio, peso);
        this.resolucion = RESOLUCION_DEF;
        this.smartTV = SMARTTV_DEF;
        this.canal = CANAL_DEF;
    }

    // Constructor con todos los atributos
    public Television(double precio, double peso, int resolucion, boolean smartTV, String canal) {
        super(precio, peso);
        this.resolucion = resolucion;
        this.smartTV = smartTV;
        this.canal = canal;
    }

    // Getters
    public int getResolucion() {
        return resolucion;
    }

    public boolean isSmartTV() {
        return smartTV;
    }

    public String getCanal() {
        return canal;
    }

    // PrecioFinal
    @Override
    public double precioFinal() {
        double precioFinal = super.precioFinal();

        if (resolucion > 40) {
            precioFinal += precioFinal * 0.30;
        }

        if (smartTV) {
            precioFinal += 50;
        }

        return precioFinal;
    }

    private static final String[] CANALES = {
            "La 1 HD", "La 2 HD", "TD HD", "Antena 3 HD",
            "Telecinco HD", "Netfilx", "HBO", "Amazon Prime"
    };

    @Override
    public void dimeAlexa() {
        if (smartTV) {
            System.out.println("Canales disponibles:");
            for (String c : CANALES) {
                System.out.println("- " + c);
            }
        } else {
            System.out.println("Esta televisión no es Smart TV.");
        }
    }
}

