public class Lavadora extends Electrodomestico implements Alexa {

    // ATRIBUTOS POR DEFECTO
    protected static final int CARGA_DEFECTO = 5;
    protected static final boolean INTELIGENTE_DEFECTO = false;
    protected static final String PROGRAMA_DEFECTO = "Económico";

    // ATRIBUTOS
    protected int carga;
    protected boolean inteligente;
    protected String programa;

    // GETTERS & SETTERS
    public boolean isInteligente() {
        return inteligente;
    }

    public void setInteligente(boolean inteligente) {
        this.inteligente = inteligente;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    // CONSTRUCTOR POR DEFECTO
    public Lavadora() {
        super();
        this.carga = CARGA_DEFECTO;
        this.inteligente = INTELIGENTE_DEFECTO;
        this.programa = PROGRAMA_DEFECTO;
    }

    // CONSTRUCTOR CON PRECIO Y PESO EL RESTO POR DEFECTO
    public Lavadora(double precioBase, double peso) {
        super(precioBase, peso);
        this.carga = CARGA_DEFECTO;
        this.inteligente = INTELIGENTE_DEFECTO;
        this.programa = PROGRAMA_DEFECTO;
    }

    //CONSTRUCTOR CON CARGA INTELIGENTE PROGRAMA Y EL RESTO DE ATRIBUTOS HEREDADOS
    public Lavadora(double precioBase, String color, char consumoEnergetico, double peso, int carga, boolean inteligente, String programa) {
        super(precioBase, color, consumoEnergetico, peso);
        this.carga = carga;
        this.inteligente = inteligente;
        this.programa = programa;
    }

    @Override
    public double precioFinal() {
        double precioFinal = super.precioFinal();

        if (this.carga > 30) {
            precioFinal += 50;
            if (this.inteligente) {
                precioFinal += 30;
            }
        }

        return precioFinal;
    }

    private static final String[] PROGRAMAS_LAVADO = {
            "Económico", "Lana", "Algodón", "Sintéticos",
            "Ropa oscura", "Rápido", "Sport"
    };

    @Override
    public void dimeAlexa() {
        if (inteligente) {
            System.out.println("Programas de lavado disponibles:");
            for (String programa : PROGRAMAS_LAVADO) {
                System.out.println("- " + programa);
            }
        } else {
            System.out.println("Esta lavadora no es inteligente.");
        }
    }
}
