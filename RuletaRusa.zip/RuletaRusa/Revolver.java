package RuletaRusa;
import java.util.Random;

public class Revolver {

    // Atributos
    private int posicionActual;
    private int posicionBala;

    // Constructor
    public Revolver() {
        generarPosiciones();
    }

    // Metodo privado para generar posiciones aleatorias
    private void generarPosiciones() {
        Random random = new Random();
        posicionActual = random.nextInt(6) + 1; // 1 a 6
        posicionBala = random.nextInt(6) + 1;   // 1 a 6
    }

    // Función disparar
    public boolean disparar() {
        boolean resultado = (posicionActual == posicionBala);
        siguienteBala();

        return resultado;
    }

    // Avanza el tambor
    public void siguienteBala() {
        posicionActual = (posicionActual+1)%6;
    }

    // Información del revolver
    @Override
    public String toString() {
        return "Revolver { " +
                "posicionActual = " + posicionActual +
                ", posicionBala = " + posicionBala +
                " }";
    }
}


