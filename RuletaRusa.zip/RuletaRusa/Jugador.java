package RuletaRusa;

public class Jugador {

    // Atributos
    private final int id;
    private final String nombre;
    private boolean vivo;

    // Constructor
    public Jugador(int id) {
        this.id = id;
        this.nombre = "Jugador " + id;
        this.vivo = true;
    }

    // Función disparar
    public void disparar(Revolver r) {
        System.out.println(nombre + " se apunta...");

        if (r.disparar()) {
            vivo = false;
            System.out.println(nombre + " HA MUERTO ");
        } else {
            System.out.println(nombre + " sigue vivo ");
        }

        // Mostrar información del revolver
        System.out.println(r.toString());
        System.out.println("------------------------");
    }

    public boolean isVivo() {
        return vivo;
    }
}

