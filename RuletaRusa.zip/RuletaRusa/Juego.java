package RuletaRusa;

import java.sql.SQLOutput;

public class Juego {

    public static void main(String[] args) {

        System.out.println("\n -- LA RULETA RUSA -- ");
        System.out.println();
        Revolver revolver = new Revolver();

        Jugador[] jugadores = new Jugador[2];
        for (int i = 0; i < jugadores.length; i++) {
            jugadores[i] = new Jugador(i + 1);
        }

        boolean finJuego = false;

        while (!finJuego) {
            for (Jugador jugador : jugadores) {
                jugador.disparar(revolver);
                if (!jugador.isVivo()) {
                    finJuego = true;
                    break;
                }
            }
        }

        System.out.println("Fin del juego");
    }
}



