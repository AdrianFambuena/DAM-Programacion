package hospital;

import java.time.LocalDate;
import java.util.Objects;

public class PacienteBase {
    private String id;
    private String nombre;
    private String apellidos;
    private LocalDate fechaNacimiento;
    private String telefono;

    public PacienteBase(String id, String nombre, String apellidos, LocalDate fechaNacimiento, String telefono) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID no puede ser nulo ni estar en blanco.");
        }

        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
    }

    // Getters y Setters
    public String getId() { return id; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PacienteBase that = (PacienteBase) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Paciente: " + nombre + " " + apellidos;
    }
}
