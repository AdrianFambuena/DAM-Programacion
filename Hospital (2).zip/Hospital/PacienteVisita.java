package hospital;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PacienteVisita extends PacienteBase {
    private LocalDateTime fechaEntrada;
    private LocalDateTime fechaSalida;
    private int prioridad; // 1-10
    private String motivo;
    private String diagnostico;
    private String tratamiento;
    private String medicoResponsable;
    private boolean atendido;

    // Listas para datos aleatorios según el requisito
    private static final List<String> DIAGNOSTICOS = new ArrayList<>(List.of("Gripe fuerte", "Fractura de radio", "Migraña", "Gastroenteritis"));
    private static final List<String> MEDICOS = new ArrayList<>(List.of("Dr. House", "Dra. Grey", "Dr. Strange"));
    private static final List<String> TRATAMIENTOS = new ArrayList<>(List.of("Reposo absoluto", "Amoxicilina 500mg", "Intervención quirúrgica"));

    public PacienteVisita(String id, int prioridad, String motivo) {
        super(id, null, null, null, null);

        if (id == null || id.isEmpty() || prioridad < 1 || prioridad > 10) {
            throw new IllegalArgumentException("ID y Prioridad (1-10) son obligatorios.");
        }
        this.prioridad = prioridad;
        this.motivo = motivo;
        this.fechaEntrada = LocalDateTime.now();
        this.atendido = false;
    }

    public void atenderPaciente(LocalDateTime salida) {
        this.fechaSalida = salida;
        Random rand = new Random();
        this.diagnostico = DIAGNOSTICOS.get(rand.nextInt(DIAGNOSTICOS.size()));
        this.medicoResponsable = MEDICOS.get(rand.nextInt(MEDICOS.size()));
        this.tratamiento = TRATAMIENTOS.get(rand.nextInt(TRATAMIENTOS.size()));
        this.atendido = true;
    }

    // Getters y Setters
    public int getPrioridad() { return prioridad; }
    public void setPrioridad(int p) { this.prioridad = p; }

    @Override
    public String toString() {
        String estado = atendido ? "ATENDIDO (Médico: " + medicoResponsable + ")" : "EN ESPERA";
        return "[" + fechaEntrada + "] ID: " + this.getId() + " | Motivo: " + motivo + " | Prioridad: " + prioridad + " | " + estado;
    }
}