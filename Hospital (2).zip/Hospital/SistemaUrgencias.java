package hospital;

import java.time.LocalDateTime;
import java.util.*;

public class SistemaUrgencias {
    private Set<PacienteBase> registroPacientes = new HashSet<>();
    private Map<String, List<PacienteVisita>> historialVisitas = new HashMap<>();

    // Colas de prioridad
    private Queue<PacienteVisita> colaLeves = new LinkedList<>();
    private Queue<PacienteVisita> colaModerados = new LinkedList<>();
    private Queue<PacienteVisita> colaGraves = new LinkedList<>();

    public void registrarPaciente(PacienteBase p) {
        if (registroPacientes.add(p)) {
            historialVisitas.put(p.getId(), new ArrayList<>());
            System.out.println("Paciente registrado correctamente.");
        } else {
            System.out.println("Error: El paciente con ID " + p.getId() + " ya existe.");
        }
    }

    public void crearVisita(String id, int prioridad, String motivo) {
        // Verificar si el paciente existe
        boolean existe = registroPacientes.stream().anyMatch(p -> p.getId().equals(id));
        if (!existe) {
            System.out.println("Error: El paciente no está registrado en el sistema.");
            return;
        }

        PacienteVisita nuevaVisita = new PacienteVisita(id, prioridad, motivo);
        historialVisitas.get(id).add(nuevaVisita);

        if (prioridad == 10) {
            atenderSiguiente(nuevaVisita);
        } else {
            clasificarEnCola(nuevaVisita);
        }
    }

    private void clasificarEnCola(PacienteVisita v) {
        int p = v.getPrioridad();
        if (p >= 1 && p <= 3) colaLeves.add(v);
        else if (p >= 4 && p <= 6) colaModerados.add(v);
        else if (p >= 7 && p <= 9) colaGraves.add(v);
    }

    // Sobrecarga para atención inmediata (Prioridad 10)
    private void atenderSiguiente(PacienteVisita v) {
        v.atenderPaciente(LocalDateTime.now());
        System.out.println("ATENCIÓN CRÍTICA REALIZADA: " + v);
    }

    // Atención normal por orden de colas
    public void atenderSiguiente() {
        PacienteVisita proximo = null;

        if (!colaGraves.isEmpty()) proximo = colaGraves.poll();
        else if (!colaModerados.isEmpty()) proximo = colaModerados.poll();
        else if (!colaLeves.isEmpty()) proximo = colaLeves.poll();

        if (proximo != null) {
            proximo.atenderPaciente(LocalDateTime.now());
            System.out.println("Paciente atendido: " + proximo);
        } else {
            System.out.println("No hay pacientes en las colas de espera.");
        }
    }

    public void mostrarEstadoColas() {
        System.out.println("Graves: " + colaGraves.size() + " | Moderados: " + colaModerados.size() + " | Leves: " + colaLeves.size());
    }

    public void mostrarHistorial(String id) {
        List<PacienteVisita> visitas = historialVisitas.get(id);
        if (visitas == null || visitas.isEmpty()) {
            System.out.println("No hay historial para el ID: " + id);
        } else {
            System.out.println("--- Historial de " + id + " ---");
            visitas.forEach(System.out::println);
        }
    }
}