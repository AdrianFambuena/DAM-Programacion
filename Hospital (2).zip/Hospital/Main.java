package hospital;

import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {
            SistemaUrgencias sistemaUrgencias = new SistemaUrgencias();
            Scanner sc = new Scanner(System.in);
            int opcion;

            do {
                System.out.println("\n--- URGENCIAS HOSPITALARIAS ---");
                System.out.println("1. Registrar Paciente\n2. Nueva Visita\n3. Atender Siguiente\n4. Ver Colas\n5. Historial\n6. Salir");
                System.out.print("Escribe la opción: ");
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.print("ID: "); String id = sc.nextLine();
                        System.out.print("Nombre: "); String nom = sc.nextLine();
                        System.out.print("Apellidos: "); String ape = sc.nextLine();

                        try {
                            PacienteBase p = new PacienteBase(id, nom, ape, null, null);
                            sistemaUrgencias.registrarPaciente(p);
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;
                    case 2:
                        System.out.print("ID Paciente: "); String idV = sc.nextLine();
                        System.out.print("Prioridad (1-10): "); int p = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Motivo: "); String m = sc.nextLine();
                        sistemaUrgencias.crearVisita(idV, p, m);
                        break;
                    case 3:
                        sistemaUrgencias.atenderSiguiente();
                        break;
                    case 4:
                        sistemaUrgencias.mostrarEstadoColas();
                        break;
                    case 5:
                        System.out.print("ID: "); String idH = sc.nextLine();
                        sistemaUrgencias.mostrarHistorial(idH);
                        break;
                }
            } while (opcion != 6);
        }
    }

