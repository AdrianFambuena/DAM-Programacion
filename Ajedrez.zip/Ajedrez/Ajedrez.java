import java.util.Scanner;

public class Ajedrez {

    // Constantes proporcionadas
    final static int FILAS = 8;
    final static int COLUMNAS = 8;
    final static char CUADROBLANCO = '\u25A1';
    final static char CUADRONEGRO = '\u25A0';
    final static char DAMA = 'D';

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        char[][] tablero = new char[FILAS][COLUMNAS];

        // Dibujar tablero inicial
        inicializarTablero(tablero);
        mostrarTablero(tablero);

        // Pedir posición de la dama
        int fila = -1;
        int columna = -1;
        boolean valido = false;

        while (!valido) {
            System.out.print("\nDame la posición de la dama (ej: a8): ");
            String posicion = sc.nextLine().toLowerCase();

            if (posicion.length() == 2) {
                char letra = posicion.charAt(0);
                char numero = posicion.charAt(1);

                if (letra >= 'a' && letra <= 'h' && numero >= '1' && numero <= '8') {
                    columna = letra - 'a';
                    fila = FILAS - (numero - '0');
                    valido = true;
                } else {System.out.println("Posición fuera del tablero.");
                }
            } else {
                System.out.println("Formato incorrecto.");
            }
        }

        // Colocar la dama
        tablero[fila][columna] = DAMA;

        // Mostrar tablero con la dama
        System.out.println();
        mostrarTablero(tablero);

        sc.close();
    }

    // Inicializa el tablero con cuadros blancos y negros
    public static void inicializarTablero(char[][] tablero) {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if ((i + j) % 2 == 0) {
                    tablero[i][j] = CUADROBLANCO;
                } else {
                    tablero[i][j] = CUADRONEGRO;
                }
            }
        }
    }

    // Muestra el tablero en pantalla
    public static void mostrarTablero(char[][] tablero) {
        for (int i = 0; i < FILAS; i++) {
            System.out.print((FILAS - i) + " ");
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.print(tablero[i][j] + " ");
            }
            System.out.println();
        }

        System.out.print("  ");
        for (char c = 'a'; c <= 'h'; c++) {
            System.out.print(c + " ");
        }
        System.out.println();
    }
}

